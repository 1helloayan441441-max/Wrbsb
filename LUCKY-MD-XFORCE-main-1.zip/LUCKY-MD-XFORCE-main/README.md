# 🌟 VISION SIXTH MD 🚀

[![VISION SIXTH](https://img.shields.io/badge/Vision__Sixth-Official_Website-blue?style=for-the-badge&logo=googlechrome&logoColor=white)](https://ayan6v.blogspot.com)

---

## 📊 Project Overview

👤 **Developer**: [Ayan](https://ayan6v.blogspot.com)  
🤖 **Bot Name**: Vision Sixth MD (V6A)  
📝 **Description**: A powerful, multi-device WhatsApp bot built for speed, customization, and seamless performance.

---

## 🎯 Features

✨ **Anti-Features**: Anti-call, anti-delete, ultra-short session  
✨ **Auto-Features**: Auto status view/read, auto message reaction  
✨ **Dual Mode**: Fully functional in both Groups and Private DMs  
✨ **Privacy Control**: Public and Private deployment modes  
✨ **Hosting**: Built for lightweight and 24/7 cloud-hosting platforms  
✨ **Support**: Active branding maintained under Vision Sixth  

---

## 🚀 Deployment Options

### 🌐 Cloud Platforms

#### 1. **Heroku**  
<details><summary>Steps</summary>
1. Fork this repository to your GitHub account.  
2. Open your Heroku dashboard and create a new app.  
3. Connect your GitHub account and select this forked repository.  
4. Go to Settings → Reveal Config Vars, and add your `SESSION_ID` and other configuration variables.  
5. Go to the Deploy tab and click **Deploy Branch**.  
</details>

#### 2. **Railway**  
<details><summary>Steps</summary>
1. Log into Railway.app and click on **New Project**.  
2. Select **Deploy from GitHub repository**.  
3. Choose this repository from your list.  
4. Go to the Variables tab and add your environment variables (`SESSION_ID`, `PREFIX`, etc.).  
5. Click deploy and wait for the build to complete.  
</details>

#### 3. **Koyeb**  
<details><summary>Steps</summary>
1. Open the Koyeb console and create a new service.  
2. Select GitHub as the deployment method and authorize this repository.  
3. Set your environment variables in the configuration panel.  
4. Set the build and run commands if prompted, then click **Deploy**.  
</details>

#### 4. **Render**  
<details><summary>Steps</summary>
1. Go to the Render Dashboard and click **New +** → **Web Service**.  
2. Connect your GitHub account and select this repository.  
3. Choose `Node` as the environment.  
4. Add your Environment Variables in the Advanced section.  
5. Click **Create Web Service**.  
</details>

---

## 🛠️ Setup Guide

1. **Fork the Repo**: Click the "Fork" button at the top right of this page to copy it to your profile.  
2. **Get Session ID**: Scan the QR code or use the pairing code link from your setup server to obtain your unique session string.  
3. **Choose Host**: Select any of the cloud platform hosting services listed above.  
4. **Configure Environment**: Make sure to accurately input your variables, especially `SESSION_ID` and `OWNER_NUMBER`.  
5. **Start Bot**: Deploy the code, and the script will automatically connect and turn online.  

---

## 🌐 Official Platform

💻 **Website**: [ayan6v.blogspot.com](https://ayan6v.blogspot.com)  
📢 **Stay Updated**: Visit the official site for latest news, updates, and configuration layouts regarding Vision Sixth projects.  

---

## 📝 License

📜 **License**: This project is open-source and distributed under the [MIT License](LICENSE).  
📢 **Credits**: Maintained and customized with ❤️ by **Ayan**.  
